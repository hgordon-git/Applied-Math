function [AV,NUM,L,Cycles]=Boolcycleslss(R,U,K,N,IC)

% This function produces the limit cycles that are reached from the
% set of initial conditions in vector IC. The cycles and and their 
% lengths are recorded in vectors Cycles and L, respectively. This
% function also produces the total number of Cycles (NUM) and their 
% average length (AV). 

s=-1;
% s acts as a separator in vector Cycles. Its value is set to -1, 
% so that it cannot be confused with a network state.
if N > 50
	h = 2^50;
else
	h = 2^N;
end

Cycles=s;
L=[];
for i=1:length(IC)
	rep=0;
	% Sets repetition counter to 0.
	x(1)=IC(i);
	for k=2:h+1
		% This loop checks for the first repeated state
		if (rep==0)
			% If no state has occured more than once up to this point, compute
			% the next state. 
			x(k)=nextstate(R,U,K,N,x(k-1));
			r=find(x==x(k));
			%If x(k) occured before, r will contain two indices.
			if (length(r)>1)
				rep=1;
				a=r(1)
				b=r(2)
				LC=x(a:b-1)
				% LC represents the limit cycle that is reached from this
				% initial state.
				if a>1
					% a>1 means that there is a  path from IC to the limit cycle.
					% Since the cycle has a basin, it must be attractive.
					g=find(Cycles==x(a));
					TF=isempty(g);
					if (TF==1)
						% If g is empty, x(a) is NOT in the Cycles vector, so this is a new cycle.
						% We need to add it to the Cycles vector, and store its length in L. 
						% As noted earlier, s separates two consecutive cycles.
						Cycles=[Cycles LC s];
						q=length(LC);
						L=[L q];   
					end
				end
				x=-2*ones(1,10);
				% Reset vector x to values that cannot be system states. This vector will
				% be partially overwritten with actual states in the next step. 
				break
				% Exit the for loop, and check out the next initial state.
			end
		end
	end
end

NUM=length(L);
AV=sum(L)/NUM;
	 
		
