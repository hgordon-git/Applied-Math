function [R,U,P1,P2]=rndRU(N,K)
% This function produces randomized matrices R and U. Vectors P1
% and P2 indicate which rows of U may need fixing, and why.
P1=[];
P2=[];
X=rand(N,2^K);
% X is a matrix whose elements are random numbers on interval (0,1). 
R=round(X);
% This function rounds the elements of X to zeros and ones.
S=randi([1,N],N,K);
% S is an NxK matrices with integer elements that range from 1 to N.
W=sort(S');
U=W';
% These two operations ensure that the elements in each row of U 
% are arranged in ascending order.
for i=1:N
	v=U(i,:);
	L=find(v==i);
	T=isempty(L);
% Check if index i is in row i of matrix U. If this is the case, L is 
% non-empty, and T=0. This means that xi(k+1) is affected by xi(k), 
% so, row i should be stored in P1.
	if (T==0)
		P1=[P1 i];
	end
	for m=1:K
		c=v(m);
		r=find(v==c);
		if (length(r) >1)
% If length(r) >1, there are repeated indices in row i of matrix U. 
% Row i is therefore stored in P2.
			P2=[P2 i];
			break
% There is no more need to examine row i at this point.
		end
	end
end