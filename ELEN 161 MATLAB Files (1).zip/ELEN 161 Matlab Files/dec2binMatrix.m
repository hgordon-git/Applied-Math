function mat = dec2binMatrix(m)

v = dec2bin(m);
len = ceil(log2(length(m)));

mat = zeros(length(v),len);

for x=1:length(v)
	for y=1:len
		mat(x,y) = str2num(v(x,y));
	end
end
