function mat = dec2binMatrixN(m,n)

v = dec2bin(m);
len = length(v);
h = zeros(1,n-len);

for x=1:len
		w(1,x) = str2num(v(1,x));
end

mat = [h w];
