function m=nextstate(R,U,K,N,prev)

% This function produces the next state of the Boolean network
% defined by R,U,K and N given the previous one.

X=dec2binMatrixN(prev, N);

% Vector X is the binary equivalent of the previous state.

z=[];
for i=1:N
	w=R(i,:);
	v=U(i,:);
	s=0;
% Computation of Xi(k+1).
	for j=1:K
		s=s+(2^(K-j))*X(v(j));
	end
	p=s+1;
% Value s=a corresponds to w(a+1). For example. s=0 corresponds to
% input [0 0] which produces output w(1), s=1 corresponds to
% [0 1] which produces output w(2), etc.

	z=[z w(p)];
end
% Vector z represents the next state in binary form.
m=0;
for r=1:N
	m=m+2^(N-r)*z(r);
end

% m is the decimal equivalent of z.
		
