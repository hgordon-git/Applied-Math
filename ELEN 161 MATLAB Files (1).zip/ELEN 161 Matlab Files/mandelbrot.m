function [BX,BY,WX,WY]=mandelbrot(Xmin,Xmax,Ymin,Ymax,s,K,R)

% This function is designed to compute points that belong to the Mandelbrot
% set. Xmin,Xmax,Ymin,Ymax are the limits of the sxs grid.
% s defines the spacing of points on the grid.
% K is the number of iterations, R is the convergence criterion and c is
% the complex parameter.

m=1; t=1;
% Initialize indices of output vectors
for x=Xmin:s:Xmax
    div=0;
% Set divergence flag to zero
    for y=Ymin:s:Ymax
        c=x+y*i;
% This is the next c to be tested for boundedness
        z=0;
% Set initial condition for sequence z(k) to 0.
        for n=1:K
            z=z^2+c;
            if (abs(z)>R)
% The sequence is unbounded, so place x and y in BX and BY
                BX(t)=x;
                BY(t)=y;
                t=t+1;
                div=1;
% Set divergence flag to 1, since the sequence is unbounded.
                break
% Go to the end of the current "for loop".
            end
        end
% If all K iterates have magnitudes less than R, div will equal
% zero at this point. If not, div=1, so we skip the "if" 
% statement below.
        if div==0
% The sequence is bounded, so place x and y in WX and WY
            WX(m)=x;
            WY(m)=y;
            m=m+1;
        end
        div=0;
% Reset divergence flag
    end
end