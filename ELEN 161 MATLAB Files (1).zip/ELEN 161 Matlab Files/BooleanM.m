function M=BooleanM(R,U,K,N)

% This function forms matrix M for an NK Boolean network. Matrices R and U
% describe the network structure. Specifically, row i of R contains 
% function Fi(x)(transposed), and row i of matrix U contains the K states
% that influence the dynamics of node i. 

X=dec2binMatrix(0:(2^N)-1);

% This function creates a matrix of binary representations
% of 0 to 2^N-1. Each row corresponds to a different number.

M=zeros(2^N,2);
C=zeros(2^N,N);
T=0:1:(2^N)-1;
M(:,1)=T';

% Initializing matrices M and C. Matrix C corresponds to the rhs of the 
% overall truth table. The truth table itself is composed of X (lhs) and
% C (rhs).

for i=1:N
% Computation of column i of matrix C    
    w=R(i,:);
    v=U(i,:);
% w corresponds to Fi, and v contains the nodes that influence node i.
    s=zeros(2^N,1);
	for j=1:K
        s=s+(2^(K-j))*X(:,v(j));
    end
% s is a vector that corresponds to the decimal equivalent of different
% input combinations for node i.
    for m=1:2^N    
		p=s(m)+1;
% Value s=a corresponds to w(a+1). For example, s=0 corresponds to input
% [0 0] which produces output w(1), s=1 corresponds to input
% [0 1] which produces output w(2),etc.        
		C(m,i)=w(p);
    end
end

C 

for l=1:2^N
	M(l,2)=0;
	for r=1:N
		M(l,2)=M(l,2)+2^(N-r)*C(l,r);
	end
% This loop converts each binary row of C into a decimal, which is placed
% in matrix M.
end