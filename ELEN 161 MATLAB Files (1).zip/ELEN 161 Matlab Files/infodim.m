function [DI,q]=infodim(x,y,a,b,s)
% This function records how many time each box has been visited by the
% iterates, and stores the information in matrix A. a and b are the limits 
% of the rectangle in which the attractor is embedded, and s represents the
% dimension of the grid. x and y are vectors of points that belong to the 
% attractor. 

N=length(x);
% N is the number of points on the attractor
unit=(b-a)/s;
% Unit represents the size of each box in the grid. 
A=zeros(s,s);
% All boxes are initially empty, so A is set to zero.
for k=1:N
    w=s:-1:1;
% This is a reverse permutation, which ensures that the "boxes" 
% correspond to matrix indices.
    c=(x(k)-a)/unit;
    r=(y(k)-a)/unit;
    c1=ceil(c);
    r1=ceil(r);
    COL=c1;
    ROW=w(r1);
    A(ROW,COL)=A(ROW,COL)+1;
end
m=0;
H=0;
W=A/N;
% W is the matrix of probabilities that boxes will be visited, which is
% obtained by scaling A by N (N is the total number of points on the
% attractor)
for i=1:s
    for j=1:s
        m=m+1;
        p(m)=W(i,j);
        if p(m)>0           
            H=H-p(m)*log2(p(m));
        end
    end
end
DI=H/log2(s);
% p is the vector of probabilities that correspond to the boxes. The boxes
% are counted from left to right, row by row. DI represents the information
% dimension. 

t=find(p);
q=length(t);
%t contains indices of all nonzero elements in p (these are the boxes that
%have been visited). q represents the total number of boxes that have been
%visited. 
