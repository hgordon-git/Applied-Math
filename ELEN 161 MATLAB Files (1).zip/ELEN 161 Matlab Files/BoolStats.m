function [Avg_NUM, Avg_L] = BoolStats(N,K,iterations)

	Ls = [];
	NUMs = [];

	for i=1:iterations
		[R,U,P1,P2]=rndRU(N,K);
		if N == K
			r = 1:1:N;
			for j=1:N
				U(j,:) = r;
			end
		else
			U=rndRUfix(U,K,N,P1,P2);
		end
		IC = randi(2^N, 1, 100);
		[AV,NUM,L,Cycles]=Boolcycleslss(R,U,K,N,IC);

		Ls = [Ls L];
		NUMs = [NUMs NUM];
	end

	Avg_L = sum(Ls)/length(Ls);
	Avg_NUM = sum(NUMs)/length(NUMs);
