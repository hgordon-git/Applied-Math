function M=matrixM(R,L)

% This function forms matrix M, given rule R and length L
X=dec2binMatrix(0:(2^L)-1);

% This function creates a matrix of binary representations
% of 0 to 2^L-1. Each row corresponds to different numbers.
M=zeros(2^L,2);
C=zeros(2^L,L);
T=0:1:(2^L)-1;
M(:,1)=T';

% Initializing matrices M and C. Matrix C corresponds to the rhs of the overall truth table
for k=1:L
	if (k==1)
		s=4*X(:,L)+2*X(:,1)+X(:,2);
		% Cell L plays the role of the left neighbor for cell 1
		for n=1:2^L
			p=s(n)+1;
			C(n,k)=R(p);
		end
	elseif (k==L)
		s=4*X(:,L-1)+2*X(:,L)+X(:,1);
	% Cell 1 plays the role of the left neighbor for cell L
	for n=1:2^L
		p=s(n)+1;
		C(n,k)=R(p);
	end
	else
		s=4*X(:,k-1)+2*X(:,k)+X(:,k+1);

		% Vector s contains the decimal equivalents for the three states that determine the next state of
		% cell k. 

		for n=1:2^L
			p=s(n)+1;
			C(n,k)=R(p);
		end
	end
end
for i=1:2^L
	M(i,2)=0;
	for m=1:L
		M(i,2)=M(i,2)+2^(L-m)*C(i,m);
	end
% This loop converts each binary row of C into a decimal, which is placed in matrix M.
end