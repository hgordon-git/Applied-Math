function U=rndRUfix(U,K,N,P1,P2)

% P1 => index in U(index)
% P2 => duplicate values in U(index)

P = unique([P1 P2]);

for index=1:length(P)
	flag = true;
	% Required to enter loop
	while flag
		randValue = sort(randi(N,1,K));

		if checkForIndex(randValue,P(index))==-1 && checkForDuplicates(randValue)==-1
			% No errors. Replace row in U
			U(P(index),:) = randValue;
			flag = false;
		end
	end
end

function ret=checkForIndex(X,index)
	% return 1 if index exists
	% if not, return -1
	if isempty(find(X == index))
		ret = -1;
	else
		ret = 1;
	end

function ret=checkForDuplicates(X)
	% return 1 if duplicates exist
	% if none, return -1

	if length(X) == length(unique(X))
		ret = -1;
	else
		ret = 1;
	end


